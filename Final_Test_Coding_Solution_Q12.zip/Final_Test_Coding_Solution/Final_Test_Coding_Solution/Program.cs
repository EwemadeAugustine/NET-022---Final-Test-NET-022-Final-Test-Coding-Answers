﻿using System;
using System.Threading.Tasks;

class Program
{
	static void Main()
	{


		/*Question 12
		 * 
		 * Write a code which fulfills below requirements:

1)   A method which returns a random integer between 1 to 10000 using Func. This method should return the number. Use Lamba expressions.

2)   A method which could take in a Func<int> and return a string which outputs "The Generates Number is: {number"}

3)   Implement this using Task Factory and use Continue With to Chanin these two methods.

5)   Final result which is passed from the second method needs to be printed using Console.WriteLine */





		// Step 1: Using Task.Factory to execute the methods asynchronously
		Task<string> resultTask = Task.Factory.StartNew(() =>
		{
			// Step 2: These method returns number using Func
			Func<int> generateRandomNumber = () =>
			{
				Random random = new Random();
				return random.Next(1, 10001); 
			};

			// Step 3: These method takes a Funt<int> and returns the formatted String
			Func<Func<int>, string> formatNumber = (func) =>
			{
				int number = func();
				return $"The Generated Number is: {number}";
			};

			
			return formatNumber(generateRandomNumber);

		});

		// Step 4: Chaining tasks using ContinueWith
		resultTask.ContinueWith(task =>
		{
			// Step 5: Printing the final result
			Console.WriteLine(task.Result);
		});

		
		resultTask.Wait();









	}
}
