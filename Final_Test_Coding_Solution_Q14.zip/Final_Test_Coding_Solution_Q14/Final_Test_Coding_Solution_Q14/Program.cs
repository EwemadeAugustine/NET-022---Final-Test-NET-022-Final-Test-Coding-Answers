﻿using System;

class Program
{

	/*Question 14

Write classes for events, one class which exposes an event and another which handles the event.

Choose any scenario you prefer to build your code.



1)   Create a class to pass as an argument for the event handlers (EventArgs class)

2)   Set up the delegate for the event

3)   Declare the code for the event

4)   Create code the will be run when the event occurs (Event Handler)

5)   Associate the event with the event handler*/



	// Answer 1
	public class TemperatureEventArgs : EventArgs
	{
		public int Temperature { get; set; }

		public TemperatureEventArgs(int temperature)
		{
			Temperature = temperature;
		}
	}

	// 2. delegate for the event
	public delegate void TemperatureExceededEventHandler(object sender, TemperatureEventArgs e);

	public class TemperatureSensor
	{





		// 3. code for the event
		public event TemperatureExceededEventHandler TemperatureExceeded;

		public void CheckTemperature(int currentTemperature)
		{

			if (currentTemperature > 30)
			{
				OnTemperatureExceeded(currentTemperature);
			}
		}




		// 4) Code that will be run when the event occurs
		protected virtual void OnTemperatureExceeded(int temperature)
		{
			// Raise the event
			TemperatureExceeded?.Invoke(this, new TemperatureEventArgs(temperature));
		}
	}

	public class TemperatureDisplay
	{


		// 5) Event Handler
		public void OnTemperatureExceeded(object sender, TemperatureEventArgs e)
		{
			Console.WriteLine($"Warning: The temperature has exceeded the threshold! Current temperature: {e.Temperature}°C");
		}
	}

	static void Main(string[] args)
	{
		// Instantiate the TemperatureSensor and TemperatureDisplay classes
		TemperatureSensor sensor = new TemperatureSensor();
		TemperatureDisplay display = new TemperatureDisplay();

		// Associate the event with the event handler
		sensor.TemperatureExceeded += display.OnTemperatureExceeded;

		// Simulate temperature checks
		sensor.CheckTemperature(25); // This won't trigger the event
		sensor.CheckTemperature(35); // This will trigger the event
	}
}
